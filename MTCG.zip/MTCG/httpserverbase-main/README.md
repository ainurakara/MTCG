# HttpServerBase



## Basis für die Implementierung des Http-Servers

Der Inhalt dieser Basisimplementierung wird im Zuge der SWEN1-LV gemeinsam erarbeitet.
